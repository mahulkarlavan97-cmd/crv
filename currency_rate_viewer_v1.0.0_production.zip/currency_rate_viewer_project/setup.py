from setuptools import setup, find_packages

setup(
    name="currency_rate_viewer",
    version="1.0.0",
    author="StudentLife Hack Team",
    description="A robust, production-ready Python Currency Rate Viewer & Analytics Application",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "matplotlib>=3.5.0",
    ],
    entry_points={
        "console_scripts": [
            "currency-rate-viewer=main:main",
        ],
    },
)
