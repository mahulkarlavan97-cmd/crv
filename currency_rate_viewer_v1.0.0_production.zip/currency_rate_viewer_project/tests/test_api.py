import unittest
from currency_rate_viewer.api import ExchangeRateAPI

class TestExchangeRateAPI(unittest.TestCase):
    def setUp(self):
        self.api = ExchangeRateAPI()

    def test_convert_offline_fallback(self):
        converted, rate, usd_eq, is_live, msg = self.api.convert("USD", "EUR", 100.0)
        self.assertGreater(converted, 0)
        self.assertGreater(rate, 0)
        self.assertEqual(usd_eq, 100.0)

    def test_same_currency(self):
        converted, rate, usd_eq, is_live, msg = self.api.convert("USD", "USD", 150.0)
        self.assertEqual(converted, 150.0)
        self.assertEqual(rate, 1.0)

if __name__ == '__main__':
    unittest.main()
