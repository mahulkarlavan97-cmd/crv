import unittest
import os
import shutil
from currency_rate_viewer.storage import StorageManager
from currency_rate_viewer.models import Transaction

class TestStorageManager(unittest.TestCase):
    def setUp(self):
        self.json_file = "test_conversions.json"
        self.csv_file = "test_conversions.csv"
        self.audit_log = "test_audit.log"
        self.storage = StorageManager(self.json_file, self.csv_file, self.audit_log)

    def tearDown(self):
        for f in [self.json_file, self.csv_file, self.audit_log]:
            if os.path.exists(f):
                os.remove(f)

    def test_save_and_load(self):
        txns = [Transaction(id="t1", timestamp="2026-11-20T10:00:00", from_currency="USD", to_currency="EUR", amount=100.0, converted_amount=92.5, rate=0.925, usd_equivalent=100.0)]
        self.storage.save_transactions(txns)
        loaded, msg = self.storage.load_transactions()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].id, "t1")

if __name__ == '__main__':
    unittest.main()
