"""
ANSI Menu-Driven Command Line Interface
"""

import sys
import os
from typing import Optional
from .engine import ConversionEngine
from .analytics import AnalyticsEngine
from .exporter import Exporter
from .utils import Color, colorize, prompt_currency, prompt_float, prompt_string
from .config import SUPPORTED_CURRENCIES

class CommandLineInterface:
    def __init__(self, engine: ConversionEngine):
        self.engine = engine

    def run(self):
        while True:
            self.display_header()
            self.display_menu()
            choice = input(colorize("\nEnter menu choice [0-7]: ", Color.BOLD)).strip()

            if choice == '1':
                self.handle_conversion()
            elif choice == '2':
                self.handle_view_history()
            elif choice == '3':
                self.handle_search()
            elif choice == '4':
                self.handle_analytics()
            elif choice == '5':
                self.handle_bulk_import()
            elif choice == '6':
                self.handle_export()
            elif choice == '7':
                self.handle_gui_launch()
            elif choice == '0':
                print(colorize("\nThank you for using Currency Rate Viewer! Goodbye.", Color.OKGREEN))
                break
            else:
                print(colorize("Invalid selection. Please enter a digit from 0 to 7.", Color.FAIL))
            
            input(colorize("\nPress Enter to return to main menu...", Color.SUBTLE if hasattr(Color, 'SUBTLE') else Color.BOLD))

    def display_header(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        print(colorize("==================================================", Color.HEADER))
        print(colorize("         CURRENCY RATE VIEWER v1.0.0              ", Color.BOLD))
        print(colorize("==================================================", Color.HEADER))
        print(f" Supported Currencies: {', '.join(SUPPORTED_CURRENCIES[:8])}...")
        print(f" Loaded Records      : {len(self.engine.transactions)}")
        print("--------------------------------------------------")

    def display_menu(self):
        print(colorize("1.", Color.OKCYAN) + " Convert Currency (Live Rate + API/Cache)")
        print(colorize("2.", Color.OKCYAN) + " View Transaction History")
        print(colorize("3.", Color.OKCYAN) + " Search & Filter Records")
        print(colorize("4.", Color.OKCYAN) + " Generate Executive Analytics & Trends Plot")
        print(colorize("5.", Color.OKCYAN) + " Bulk Import Dataset (CSV)")
        print(colorize("6.", Color.OKCYAN) + " Export Reports (Markdown, HTML, Audit)")
        print(colorize("7.", Color.OKCYAN) + " Launch Desktop GUI Window (Tkinter)")
        print(colorize("0.", Color.FAIL) + " Exit Application")

    def handle_conversion(self):
        print(colorize("\n--- Currency Conversion ---", Color.BOLD))
        from_curr = prompt_currency("Source Currency", "USD")
        to_curr = prompt_currency("Target Currency", "EUR")
        amount = prompt_float("Amount to Convert", min_val=0.01)
        notes = prompt_string("Transaction Note/Category (optional)", "General Conversion")

        txn, is_live, msg = self.engine.convert_and_store(from_curr, to_curr, amount, notes)
        
        status_tag = colorize("[LIVE API]", Color.OKGREEN) if is_live else colorize("[OFFLINE MOCK CACHE]", Color.WARNING)
        print("\n" + colorize("=== CONVERSION RESULT ===", Color.OKGREEN))
        print(f"  Source Amount : {txn.amount:,.2f} {txn.from_currency}")
        print(f"  Converted     : {txn.converted_amount:,.2f} {txn.to_currency}")
        print(f"  Exchange Rate : 1 {txn.from_currency} = {txn.rate:.6f} {txn.to_currency}")
        print(f"  USD Equivalent: ${txn.usd_equivalent:,.2f}")
        print(f"  Rate Status   : {status_tag} {msg}")
        print(f"  Transaction ID: {txn.id}")

    def handle_view_history(self):
        txns = sorted(self.engine.transactions, key=lambda x: x.timestamp, reverse=True)
        if not txns:
            print(colorize("\nNo transaction history available.", Color.WARNING))
            return

        print(colorize(f"\n--- Transaction History ({len(txns)} records) ---", Color.BOLD))
        print(f"{'ID':<8} | {'Timestamp':<19} | {'Pair':<9} | {'Amount':<12} | {'Converted':<12} | {'USD Eq.':<10}")
        print("-" * 80)
        for t in txns[:15]:  # Display top 15
            pair = f"{t.from_currency}->{t.to_currency}"
            print(f"{t.id:<8} | {t.timestamp:<19} | {pair:<9} | {t.amount:>12.2f} | {t.converted_amount:>12.2f} | ${t.usd_equivalent:>9.2f}")
        
        if len(txns) > 15:
            print(f"... and {len(txns) - 15} more records.")

    def handle_search(self):
        print(colorize("\n--- Search & Filter Records ---", Color.BOLD))
        query = prompt_string("Keyword query in notes/ID (press Enter to skip)", "")
        curr = prompt_string("Currency filter e.g. EUR (press Enter to skip)", "").upper()
        
        results = self.engine.search_transactions(query=query, currency_filter=curr)
        print(colorize(f"\nFound {len(results)} matching records:", Color.OKGREEN))
        for t in results[:10]:
            print(f"[{t.id}] {t.timestamp} | {t.amount:.2f} {t.from_currency} -> {t.converted_amount:.2f} {t.to_currency} (${t.usd_equivalent:.2f} USD) | Notes: {t.notes}")

    def handle_analytics(self):
        print(colorize("\n--- Generating Executive Analytics ---", Color.BOLD))
        summary = AnalyticsEngine.compute_summary(self.engine.transactions)
        print(f" Total Transactions : {summary['total_transactions']}")
        print(f" Total USD Volume   : ${summary['total_volume_usd']:,.2f}")
        print(f" Average Transaction : ${summary['avg_volume_usd']:,.2f}")
        
        success = AnalyticsEngine.generate_visual_plots(self.engine.transactions, "currency_trends.png")
        if success:
            print(colorize(" Graphics plot saved to currency_trends.png", Color.OKGREEN))

    def handle_bulk_import(self):
        print(colorize("\n--- Bulk CSV Import ---", Color.BOLD))
        filepath = prompt_string("Path to CSV file to import", "data/conversions_seed.csv")
        imp, skip, errors = self.engine.bulk_import_csv(filepath)
        print(colorize(f"Import complete! Imported: {imp}, Skipped: {skip}", Color.OKGREEN))
        if errors:
            print("Errors encountered:")
            for err in errors[:5]:
                print(f"  - {err}")

    def handle_export(self):
        summary = AnalyticsEngine.compute_summary(self.engine.transactions)
        Exporter.export_markdown_report(summary, "summary_report.md")
        Exporter.export_html_report(summary, "summary_report.html")
        print(colorize("\nReports exported to summary_report.md and summary_report.html", Color.OKGREEN))

    def handle_gui_launch(self):
        print(colorize("\nAttempting to launch Graphical User Interface...", Color.OKCYAN))
        try:
            from .gui import LaunchGUI
            LaunchGUI(self.engine)
        except Exception as e:
            print(colorize(f"Unable to launch GUI window ({e}). Running in headless/terminal environment.", Color.WARNING))
