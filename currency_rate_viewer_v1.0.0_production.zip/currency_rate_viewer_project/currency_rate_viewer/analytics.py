"""
Executive Summary Aggregation and Publication-Quality Visual Plotting
"""

import os
import sys
from collections import Counter, defaultdict
from typing import Dict, Any, List
from .models import Transaction
from .config import HIGH_VOLUME_THRESHOLD_USD, DEFAULT_PLOT_PNG

# Integrate house styling from skill_scripts if present
HOUSE_AVAILABLE = False
try:
    house_path = "/workspace/skill_scripts/data-craft"
    if os.path.exists(house_path) and house_path not in sys.path:
        sys.path.insert(0, house_path)
    import house
    from house import theme, color as C, fmt
    HOUSE_AVAILABLE = True
except Exception:
    HOUSE_AVAILABLE = False

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

class AnalyticsEngine:
    @staticmethod
    def compute_summary(transactions: List[Transaction]) -> Dict[str, Any]:
        if not transactions:
            return {
                'total_transactions': 0,
                'total_volume_usd': 0.0,
                'avg_volume_usd': 0.0,
                'min_usd': 0.0,
                'max_usd': 0.0,
                'currency_pair_counts': {},
                'high_volume_transactions': [],
                'warnings': ["No transaction records available in database."]
            }

        total_txns = len(transactions)
        total_usd = sum(t.usd_equivalent for t in transactions)
        avg_usd = total_usd / total_txns if total_txns > 0 else 0.0
        min_usd = min(t.usd_equivalent for t in transactions)
        max_usd = max(t.usd_equivalent for t in transactions)

        pairs = [f"{t.from_currency}->{t.to_currency}" for t in transactions]
        pair_counts = dict(Counter(pairs).most_common(10))

        high_vol = [t for t in transactions if t.usd_equivalent >= HIGH_VOLUME_THRESHOLD_USD]
        
        warnings = []
        if len(high_vol) > 0:
            warnings.append(f"Flagged {len(high_vol)} high-volume transactions exceeding ${HIGH_VOLUME_THRESHOLD_USD:,.2f} USD equivalent.")

        return {
            'total_transactions': total_txns,
            'total_volume_usd': round(total_usd, 2),
            'avg_volume_usd': round(avg_usd, 2),
            'min_usd': round(min_usd, 2),
            'max_usd': round(max_usd, 2),
            'currency_pair_counts': pair_counts,
            'high_volume_transactions': high_vol,
            'warnings': warnings
        }

    @staticmethod
    def generate_visual_plots(transactions: List[Transaction], output_png: str = DEFAULT_PLOT_PNG) -> bool:
        if not transactions:
            return False

        sorted_txns = sorted(transactions, key=lambda x: x.timestamp)
        timestamps = [t.timestamp[:10] for t in sorted_txns]
        volumes = [t.usd_equivalent for t in sorted_txns]
        
        cum_volume = []
        curr_total = 0.0
        for v in volumes:
            curr_total += v
            cum_volume.append(curr_total)

        pairs = [f"{t.from_currency}->{t.to_currency}" for t in sorted_txns]
        pair_counts = Counter(pairs).most_common(6)
        pair_names = [p[0] for p in pair_counts]
        pair_vals = [p[1] for p in pair_counts]

        if HOUSE_AVAILABLE:
            try:
                theme.apply("report")
                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
                
                ax1.plot(range(len(cum_volume)), cum_volume, marker='o', color=C.OKABE_ITO[0], linewidth=2.5)
                ax1.set_xlabel("Transaction Sequence")
                ax1.set_ylabel("Cumulative Volume ($ USD)")
                theme.declutter(ax1)
                ax1.set_title("Cumulative Volume Growth")

                ax2.barh(pair_names, pair_vals, color=C.OKABE_ITO[1])
                ax2.set_xlabel("Transaction Count")
                theme.declutter(ax2)
                ax2.set_title("Top Currency Pair Activity")

                total_usd = sum(volumes)
                theme.title(fig, f"Processed {len(transactions)} Currency Conversions (${total_usd:,.2f} USD Volume)", 
                            "Cumulative transaction growth and pair distribution breakdown")
                theme.source(fig, "Source: Currency Rate Viewer Core Engine")

                house.save(fig, output_png)
                plt.close(fig)
                return True
            except Exception:
                pass

        # Standard Matplotlib Fallback
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        fig.suptitle(f"Currency Rate Viewer - Executive Analytics ({len(transactions)} Records)", fontsize=14, fontweight='bold')

        ax1.plot(range(len(cum_volume)), cum_volume, color='#0072B2', marker='o', linewidth=2)
        ax1.set_title("Cumulative USD Volume Over Time")
        ax1.set_xlabel("Transaction Order")
        ax1.set_ylabel("USD Equivalent ($)")
        ax1.grid(True, linestyle='--', alpha=0.5)

        ax2.barh(pair_names, pair_vals, color='#E69F00')
        ax2.set_title("Most Active Currency Pairs")
        ax2.set_xlabel("Frequency Count")
        ax2.grid(True, axis='x', linestyle='--', alpha=0.5)

        plt.tight_layout()
        plt.savefig(output_png, dpi=200, bbox_inches='tight')
        plt.close(fig)
        return True
