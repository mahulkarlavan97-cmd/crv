"""
Exchange Rate API Integration with Defensive Offline Cache Fallback
"""

import json
import urllib.request
import urllib.error
from typing import Tuple, Dict
from .config import API_ENDPOINT, API_TIMEOUT, OFFLINE_MOCK_RATES

class ExchangeRateAPI:
    def __init__(self):
        self._cache: Dict[str, Dict[str, float]] = {}

    def fetch_rates_from_api(self, base_currency: str = "USD") -> Tuple[Dict[str, float], bool, str]:
        base_currency = base_currency.upper()
        if base_currency in self._cache:
            return self._cache[base_currency], True, "Loaded from session memory cache."

        url = f"{API_ENDPOINT}{base_currency}"
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'CurrencyRateViewer/1.0'})
            with urllib.request.urlopen(req, timeout=API_TIMEOUT) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode('utf-8'))
                    if data.get('result') == 'success' and 'rates' in data:
                        rates = data['rates']
                        self._cache[base_currency] = rates
                        return rates, True, "Successfully fetched live rates from Open Exchange Rates API."
        except Exception as e:
            pass  # Fall through defensively to offline mock cache

        # Defensive fallback to offline mock table
        mock_rates = self._get_fallback_mock_rates(base_currency)
        return mock_rates, False, f"API offline or network unreachable. Fallback to local exchange rate table."

    def _get_fallback_mock_rates(self, base_currency: str) -> Dict[str, float]:
        base_currency = base_currency.upper()
        usd_rates = OFFLINE_MOCK_RATES.copy()
        if base_currency == "USD":
            return usd_rates
        
        base_to_usd = 1.0 / usd_rates.get(base_currency, 1.0)
        derived_rates = {}
        for curr, rate_vs_usd in usd_rates.items():
            derived_rates[curr] = round(rate_vs_usd * base_to_usd, 6)
        return derived_rates

    def convert(self, from_curr: str, to_curr: str, amount: float) -> Tuple[float, float, float, bool, str]:
        from_curr = from_curr.upper()
        to_curr = to_curr.upper()
        if from_curr == to_curr:
            return amount, 1.0, amount, True, "Same currency (1:1 conversion)."

        rates, is_live, msg = self.fetch_rates_from_api(from_curr)
        if to_curr in rates:
            rate = float(rates[to_curr])
        else:
            # Try via USD cross-rate
            rates_usd, _, _ = self.fetch_rates_from_api("USD")
            r_from = rates_usd.get(from_curr, 1.0)
            r_to = rates_usd.get(to_curr, 1.0)
            rate = r_to / r_from

        converted_amount = round(amount * rate, 2)
        
        # Calculate USD equivalent
        usd_rates, _, _ = self.fetch_rates_from_api("USD")
        r_from_usd = usd_rates.get(from_curr, 1.0)
        usd_eq = round(amount / r_from_usd, 2) if r_from_usd > 0 else amount

        return converted_amount, rate, usd_eq, is_live, msg
