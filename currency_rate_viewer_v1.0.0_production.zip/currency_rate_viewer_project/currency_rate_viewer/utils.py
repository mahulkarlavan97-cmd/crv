"""
Formatting, Validation, and ANSI Console Utilities
"""

import re
from typing import Optional

class Color:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def colorize(text: str, color_code: str) -> str:
    return f"{color_code}{text}{Color.ENDC}"

def sanitize_string(val: str) -> str:
    if not val:
        return ""
    return str(val).strip()

def validate_currency_code(code: str) -> bool:
    if not code:
        return False
    clean_code = code.strip().upper()
    return bool(re.match(r'^[A-Z]{3}$', clean_code))

def prompt_string(prompt_msg: str, default: str = "") -> str:
    display_prompt = f"{prompt_msg} [{default}]: " if default else f"{prompt_msg}: "
    val = input(display_prompt).strip()
    return val if val else default

def prompt_float(prompt_msg: str, min_val: Optional[float] = 0.0) -> float:
    while True:
        try:
            val_str = input(f"{prompt_msg}: ").strip()
            val = float(val_str)
            if min_val is not None and val < min_val:
                print(colorize(f"Error: Value must be at least {min_val}.", Color.FAIL))
                continue
            return val
        except ValueError:
            print(colorize("Error: Please enter a valid numerical amount.", Color.FAIL))

def prompt_currency(prompt_msg: str, default: str = "USD") -> str:
    while True:
        code = input(f"{prompt_msg} [{default}]: ").strip().upper()
        if not code:
            return default
        if validate_currency_code(code):
            return code
        print(colorize("Error: Currency code must be a 3-letter ISO code (e.g. USD, EUR, GBP).", Color.FAIL))
