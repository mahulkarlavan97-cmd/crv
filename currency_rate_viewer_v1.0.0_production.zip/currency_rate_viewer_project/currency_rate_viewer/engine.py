"""
Core Conversion and Search Engine
"""

import csv
from datetime import datetime
from typing import List, Optional, Tuple, Dict, Any
from .models import Transaction
from .api import ExchangeRateAPI
from .storage import StorageManager
from .config import HIGH_VOLUME_THRESHOLD_USD

class ConversionEngine:
    def __init__(self, storage_manager: Optional[StorageManager] = None):
        self.storage = storage_manager or StorageManager()
        self.api = ExchangeRateAPI()
        self.transactions: List[Transaction] = []
        self.reload_from_storage()

    def reload_from_storage(self) -> str:
        txns, msg = self.storage.load_transactions()
        self.transactions = txns
        return msg

    def convert_and_store(self, from_curr: str, to_curr: str, amount: float, notes: str = "", tags: Optional[List[str]] = None) -> Tuple[Transaction, bool, str]:
        converted_amt, rate, usd_eq, is_live, msg = self.api.convert(from_curr, to_curr, amount)
        
        txn = Transaction(
            id="",
            timestamp="",
            from_currency=from_curr,
            to_currency=to_curr,
            amount=amount,
            converted_amount=converted_amt,
            rate=rate,
            notes=notes,
            tags=tags or [],
            usd_equivalent=usd_eq
        )
        txn.validate()
        
        self.transactions.append(txn)
        self.storage.save_transactions(self.transactions)
        
        audit_msg = f"Converted {amount:.2f} {from_curr} -> {converted_amt:.2f} {to_curr} (Rate: {rate:.4f}, USD Eq: ${usd_eq:.2f})"
        if usd_eq >= HIGH_VOLUME_THRESHOLD_USD:
            audit_msg += " [HIGH VOLUME WARNING]"
        self.storage.log_audit("CONVERT", audit_msg)
        
        return txn, is_live, msg

    def search_transactions(
        self, 
        query: str = "", 
        currency_filter: str = "", 
        min_amount: Optional[float] = None,
        max_amount: Optional[float] = None
    ) -> List[Transaction]:
        results = self.transactions
        if currency_filter:
            c_filter = currency_filter.upper().strip()
            results = [t for t in results if t.from_currency == c_filter or t.to_currency == c_filter]
        
        if query:
            q = query.lower().strip()
            results = [t for t in results if q in t.notes.lower() or q in t.id.lower() or any(q in tag.lower() for tag in t.tags)]

        if min_amount is not None:
            results = [t for t in results if t.usd_equivalent >= min_amount]

        if max_amount is not None:
            results = [t for t in results if t.usd_equivalent <= max_amount]

        return sorted(results, key=lambda x: x.timestamp, reverse=True)

    def bulk_import_csv(self, csv_filepath: str) -> Tuple[int, int, List[str]]:
        imported_count = 0
        skipped_count = 0
        error_log = []

        try:
            with open(csv_filepath, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for idx, row in enumerate(reader, start=1):
                    try:
                        t = Transaction.from_csv_row(row)
                        t.validate()
                        self.transactions.append(t)
                        imported_count += 1
                    except Exception as e:
                        skipped_count += 1
                        error_log.append(f"Row {idx}: {str(e)}")

            if imported_count > 0:
                self.storage.save_transactions(self.transactions)
                self.storage.log_audit("BULK_IMPORT", f"Imported {imported_count} records from {csv_filepath}. Skipped {skipped_count}.")
        except Exception as e:
            error_log.append(f"File Open Error: {str(e)}")

        return imported_count, skipped_count, error_log

    def delete_transaction(self, txn_id: str) -> bool:
        initial_len = len(self.transactions)
        self.transactions = [t for t in self.transactions if t.id != txn_id]
        if len(self.transactions) < initial_len:
            self.storage.save_transactions(self.transactions)
            self.storage.log_audit("DELETE", f"Deleted transaction ID {txn_id}")
            return True
        return False
