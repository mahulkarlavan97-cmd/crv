"""
Currency Rate Viewer - Production Application Package
Version: 1.0.0
Author: StudentLife Hack Team
"""
__version__ = "1.0.0"
__author__ = "StudentLife Hack Team"
